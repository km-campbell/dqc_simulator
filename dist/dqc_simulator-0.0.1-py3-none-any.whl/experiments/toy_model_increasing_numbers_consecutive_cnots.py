# -*- coding: utf-8 -*-
"""
Created on Tue Jun 20 09:58:54 2023

@author: kenny
"""

import numpy as np
import pandas
import netsquid as ns
from netsquid.components import instructions as instr
from netsquid.components.qprocessor import (QuantumProcessor, 
                                            PhysicalInstruction)
from netsquid.qubits import ketstates as ks
from netsquid.nodes import Node, Network

from dqc_simulator.hardware.dqc_creation import create_dqc_network
from dqc_simulator.hardware.noise_models import AnalyticalDepolarisationModel
from dqc_simulator.hardware.quantum_processors import (
    create_qproc_with_analytical_noise_ionQ_aria_durations)
from dqc_simulator.qlib.gates import (INSTR_ARB_GEN, INSTR_CH, INSTR_CT, 
                                       INSTR_T_DAGGER)
from dqc_simulator.qlib.states import werner_state
from dqc_simulator.software.compilers import sort_greedily_by_node_and_time
from dqc_simulator.software.dqc_control import dqcMasterProtocol
from dqc_simulator.util.helper import (get_data_qubit_indices,
                                       get_data_collector)

def run_experiment_cat_variable_cnot_number_and_ent_errors(
                                               F_werner,
                                               p_error,
                                               max_num_logical_cnots,
                                               min_num_logical_cnots=1,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    F_werner:
        Probability of Werner state distributed by Charlie to nodes being in 
        the |Phi^+> Bell state
    p_error:
        Probability of a depolarisation error occuring during each CNOT gate
    max_num_logical_cnots : int
        Max number of logical gates in toy circuit.
    min_num_logical_cnots : int, optional
        Min number of logical gates in toy circuit
    phase: float, optional
        Relative phase of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    alpha: float, optional
        Coefficient of |0> in input state of top qubit 
        alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    #TO DO: update netsquid and re-do in terms of pandas.concat
    fidelity_data = pandas.DataFrame()
    for ii in range(min_num_logical_cnots-1, max_num_logical_cnots):
        num_logical_cnots = ii + 1
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        def create_noisy_processor():
            num_positions=7
            cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_error)
            #creating processor for all Nodes
            x_gate_duration = 1
            physical_instructions = [
                PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                    quantum_noise_model=cnot_depolar_model),
                PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                    quantum_noise_model=None, apply_q_noise_after=False,
                                    discard=True),
                PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                toplology=[0, 1]),
                PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                    topology=None),
                PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                    topology=None),
                PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                    topology=None)]
            qprocessor = QuantumProcessor(
                "noisy_qprocessor", phys_instructions=physical_instructions, 
                num_positions=num_positions, mem_noise_models=None)
            return qprocessor
        state4distribution = werner_state(F_werner)
        network = create_dqc_network(state4distribution=state4distribution,
                                     node_list=None, num_nodes=2,
                                  node_distance=4e-3, quantum_topology = None, 
                                  classical_topology = None,
                                  create_classical_2way_link=True,
                                  create_entangling_link=True,
                                  nodes_have_ebit_ready=False,
                                  node_comm_qubits_free=[0, 1],
                                  node_comm_qubit_positions=(0, 1),
                                  custom_qprocessor_func=create_noisy_processor,
                                  name="noisy_network")
        alice = network.get_node("node_0")
        bob = network.get_node("node_1")
        for node in [alice, bob]:
            node.ebit_ready = False
            node.comm_qubits_free = [0, 1]
            node.comm_qubit_positions = [0, 1]
        q1, = get_data_qubit_indices(alice, 1)
        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                       (instr.INSTR_INIT, q1, bob.name),
                       (INSTR_ARB_GEN(alpha, beta), q1, alice.name)]
        for gate_index in range(num_logical_cnots):
            gate_tuples = (gate_tuples + 
                           [(instr.INSTR_CNOT, q1, alice.name, q1, bob.name, 
                             "cat")])
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        if num_logical_cnots % 2 == 1: #if odd num gates
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                             + beta * np.kron(ks.s1, ks.s1))
        elif num_logical_cnots % 2 == 0: #if even num_logical_cnots
            desired_state = np.kron(alpha * ks.s0 + beta * ks.s1, ks.s0 )
        else:
            raise ValueError(f"num_logical_cnots ({num_logical_cnots}) is not an integer. It should be.")
        qubits2check = [(q1, alice), (q1, bob)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['F_werner'] = F_werner
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_gate_error'] = p_error
        df['num_logical_cnots'] = num_logical_cnots
        df['num_local_cnots'] = 2 * num_logical_cnots #as cat-comm remote cnot uses
                                                #two cnots
        fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_experiment_monolithic_variable_cnot_number_and_ent_errors(
                                               p_error,
                                               max_num_logical_cnots,
                                               min_num_logical_cnots=1,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    F_werner:
        Probability of Werner state distributed by Charlie to nodes being in 
        the |Phi^+> Bell state
    p_error:
        Probability of a depolarisation error occuring during each CNOT gate
    max_num_logical_cnots : int
        Max number of logical gates in toy circuit.
    min_num_logical_cnots : int, optional
        Min number of logical gates in toy circuit
    phase: float, optional
        Relative phase of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    alpha: float, optional
        Coefficient of |0> in input state of top qubit 
        alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    #TO DO: update netsquid and re-do in terms of pandas.concat
    fidelity_data = pandas.DataFrame()
    for ii in range(min_num_logical_cnots-1, max_num_logical_cnots):
        num_logical_cnots = ii + 1
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        def create_noisy_processor():
            num_positions=7
            cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_error)
            #creating processor for all Nodes
            x_gate_duration = 1
            physical_instructions = [
                PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                    quantum_noise_model=cnot_depolar_model),
                PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                    quantum_noise_model=None, apply_q_noise_after=False,
                                    discard=True),
                PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                toplology=[0, 1]),
                PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                    topology=None),
                PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                    topology=None),
                PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                    topology=None)]
            qprocessor = QuantumProcessor(
                "noisy_qprocessor", phys_instructions=physical_instructions, 
                num_positions=num_positions, mem_noise_models=None)
            return qprocessor
        monolithic_computing_node = Node("node_0",
                                         qmemory=create_noisy_processor())
        #a network, even if trivial, is needed for dqcMasterProtocol:
        network = Network("monolithic_computer_only")
        network.add_nodes([monolithic_computing_node]) 
        gate_tuples = [(instr.INSTR_INIT, [0, 1], "node_0"),
                       (INSTR_ARB_GEN(alpha, beta), 0, "node_0")]
        for gate_index in range(num_logical_cnots):
            gate_tuples = (gate_tuples + 
                           [(instr.INSTR_CNOT, 0, "node_0", 1, "node_0")])
            
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        if num_logical_cnots % 2 == 1: #if odd num gates
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                             + beta * np.kron(ks.s1, ks.s1))
        elif num_logical_cnots % 2 == 0: #if even num_logical_cnots
            desired_state = np.kron(alpha * ks.s0 + beta * ks.s1, ks.s0 )
        else:
            raise ValueError(f"num_logical_cnots ({num_logical_cnots}) is not an integer. It should be.")
        qubits2check = [(0, monolithic_computing_node), 
                        (1, monolithic_computing_node)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_gate_error'] = p_error
        df['num_local_cnots'] = num_logical_cnots 
        fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_experiment_tp_safe_variable_cnot_number_and_ent_errors(
                                               F_werner,
                                               p_error,
                                               max_num_logical_cnots,
                                               min_num_logical_cnots=1,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    F_werner:
        Probability of Werner state distributed by Charlie to nodes being in 
        the |Phi^+> Bell state
    p_error:
        Probability of a depolarisation error occuring during each CNOT gate
    max_num_logical_cnots : int
        Max number of logical gates in toy circuit.
    min_num_logical_cnots : int, optional
        Min number of logical gates in toy circuit
    phase: float, optional
        Relative phase of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    alpha: float, optional
        Coefficient of |0> in input state of top qubit 
        alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    #TO DO: update netsquid and re-do in terms of pandas.concat
    fidelity_data = pandas.DataFrame()
    for ii in range(min_num_logical_cnots-1, max_num_logical_cnots):
        num_logical_cnots = ii + 1
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        def create_noisy_processor():
            num_positions=7
            cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_error)
            #creating processor for all Nodes
            x_gate_duration = 1
            physical_instructions = [
                PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                    quantum_noise_model=cnot_depolar_model),
                PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                    quantum_noise_model=None, apply_q_noise_after=False,
                                    discard=True),
                PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                toplology=[0, 1]),
                PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                    topology=None),
                PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                    topology=None),
                PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                    topology=None)]
            qprocessor = QuantumProcessor(
                "noisy_qprocessor", phys_instructions=physical_instructions, 
                num_positions=num_positions, mem_noise_models=None)
            return qprocessor
        state4distribution = werner_state(F_werner)
        network = create_dqc_network(state4distribution=state4distribution, node_list=None, num_nodes=2,
                                  node_distance=4e-3, quantum_topology = None, 
                                  classical_topology = None,
                                  create_classical_2way_link=True,
                                  create_entangling_link=True,
                                  nodes_have_ebit_ready=False,
                                  node_comm_qubits_free=[0, 1],
                                  node_comm_qubit_positions=(0, 1),
                                  custom_qprocessor_func=create_noisy_processor,
                                  name="noisy_network")
        alice = network.get_node("node_0")
        bob = network.get_node("node_1")
        for node in [alice, bob]:
            node.ebit_ready = False
            node.comm_qubits_free = [0, 1]
            node.comm_qubit_positions = [0, 1]
        q1, = get_data_qubit_indices(alice, 1)
        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                       (instr.INSTR_INIT, q1, bob.name),
                       (INSTR_ARB_GEN(alpha, beta), q1, alice.name)]
        for gate_index in range(num_logical_cnots):
            gate_tuples = (gate_tuples + 
                           [(instr.INSTR_CNOT, q1, alice.name, q1, bob.name, 
                             "tp_safe")])
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        if num_logical_cnots % 2 == 1: #if odd num gates
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                             + beta * np.kron(ks.s1, ks.s1))
        elif num_logical_cnots % 2 == 0: #if even num_logical_cnots
            desired_state = np.kron(alpha * ks.s0 + beta * ks.s1, ks.s0 )
        else:
            raise ValueError(f"num_logical_cnots ({num_logical_cnots}) is not an integer. It should be.")
        qubits2check = [(q1, alice), (q1, bob)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['F_werner'] = F_werner
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_gate_error'] = p_error
        df['num_logical_cnots'] = num_logical_cnots
        df['num_local_cnots'] = 3 * num_logical_cnots #as tp-safe remote cnot
                                                      #uses 3 local CNOTs (
                                                      #assuming SWAPs ideal and
                                                      #abstract - not decomposed
                                                      #into CNOTs)
        fidelity_data = fidelity_data.append(df)
    return fidelity_data


#------------------------------------------------------------------------------
#with time 

def run_experiment_cat_with_analytical_noise_ionQ_aria_durations(
                                               F_werner,
                                               p_depolar_error_cnot,
                                               comm_qubit_depolar_rate,
                                               data_qubit_depolar_rate,
                                               max_num_logical_cnots,
                                               min_num_logical_cnots=1,
                                               phase = 0.,
                                               alpha=1/np.sqrt(2),
                                               sim_runtime=1e12):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    F_werner:
        Probability of Werner state distributed by Charlie to nodes being in 
        the |Phi^+> Bell state
    p_depolar_error_cnot:
        Probability of a depolarisation error occuring during each CNOT gate
    max_num_logical_cnots : int
        Max number of logical gates in toy circuit.
    min_num_logical_cnots : int, optional
        Min number of logical gates in toy circuit
    phase: float, optional
        Relative phase of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    alpha: float, optional
        Coefficient of |0> in input state of top qubit 
        alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    #TO DO: update netsquid and re-do in terms of pandas.concat
    fidelity_data = pandas.DataFrame()
    for ii in range(min_num_logical_cnots-1, max_num_logical_cnots):
        num_logical_cnots = ii + 1
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        state4distribution = werner_state(F_werner)
        network = create_dqc_network(
                                  p_depolar_error_cnot,
                                  comm_qubit_depolar_rate,
                                  data_qubit_depolar_rate,
                                  state4distribution=state4distribution,
                                  node_list=None, num_nodes=2,
                                  node_distance=4e-3, quantum_topology = None, 
                                  classical_topology = None,
                                  create_classical_2way_link=True,
                                  create_entangling_link=True,
                                  nodes_have_ebit_ready=False,
                                  node_comm_qubits_free=[0, 1],
                                  node_comm_qubit_positions=(0, 1),
                                  custom_qprocessor_func=( 
                                      create_qproc_with_analytical_noise_ionQ_aria_durations),
                                  name="noisy_network",
                                  single_qubit_gate_time=135 * 10**3,
                                  two_qubit_gate_time=600 * 10**3,
                                  measurement_time=300 * 10**3,
                                  alpha=alpha, beta=beta,
                                  num_positions=20,
                                  num_comm_qubits=2)
        alice = network.get_node("node_0")
        bob = network.get_node("node_1")
        for node in [alice, bob]:
            node.ebit_ready = False
            node.comm_qubits_free = [0, 1]
            node.comm_qubit_positions = [0, 1]
        q1, = get_data_qubit_indices(alice, 1)
        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                       (instr.INSTR_INIT, q1, bob.name),
                       (INSTR_ARB_GEN(alpha, beta), q1, alice.name)]
        for gate_index in range(num_logical_cnots):
            gate_tuples = (gate_tuples + 
                           [(instr.INSTR_CNOT, q1, alice.name, q1, bob.name, 
                             "cat")])
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        if num_logical_cnots % 2 == 1: #if odd num gates
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                             + beta * np.kron(ks.s1, ks.s1))
        elif num_logical_cnots % 2 == 0: #if even num_logical_cnots
            desired_state = np.kron(alpha * ks.s0 + beta * ks.s1, ks.s0 )
        else:
            raise ValueError(f"num_logical_cnots ({num_logical_cnots}) is not an integer. It should be.")
        qubits2check = [(q1, alice), (q1, bob)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['F_werner'] = F_werner
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_depolar_error_cnot'] = p_depolar_error_cnot
        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
        df['num_logical_cnots'] = num_logical_cnots
        df['num_local_cnots'] = 2 * num_logical_cnots #as cat-comm remote cnot uses
                                                      #two cnots
        fidelity_data = fidelity_data.append(df)
    return fidelity_data


def run_experiment_monolithic_with_analytical_noise_ionQ_aria_durations(
                                               p_depolar_error_cnot,
                                               comm_qubit_depolar_rate,
                                               data_qubit_depolar_rate,
                                               max_num_logical_cnots,
                                               min_num_logical_cnots=1,
                                               phase = 0.,
                                               alpha=1/np.sqrt(2),
                                               sim_runtime=1e12):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    F_werner:
        Probability of Werner state distributed by Charlie to nodes being in 
        the |Phi^+> Bell state
    p_error:
        Probability of a depolarisation error occuring during each CNOT gate
    max_num_logical_cnots : int
        Max number of logical gates in toy circuit.
    min_num_logical_cnots : int, optional
        Min number of logical gates in toy circuit
    phase: float, optional
        Relative phase of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    alpha: float, optional
        Coefficient of |0> in input state of top qubit 
        alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    #TO DO: update netsquid and re-do in terms of pandas.concat
    fidelity_data = pandas.DataFrame()
    for ii in range(min_num_logical_cnots-1, max_num_logical_cnots):
        num_logical_cnots = ii + 1
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        monolithic_computing_node = Node("node_0",
                                         qmemory=( 
                                             create_qproc_with_analytical_noise_ionQ_aria_durations(
                                                                                  p_depolar_error_cnot,
                                                                                  comm_qubit_depolar_rate,
                                                                                  data_qubit_depolar_rate,
                                                                                  single_qubit_gate_time=135 * 10**3,
                                                                                  two_qubit_gate_time=600 * 10**3,
                                                                                  measurement_time=300 * 10**3,
                                                                                  alpha=alpha, beta=beta,
                                                                                  num_positions=20,
                                                                                  num_comm_qubits=2)))
        #a network, even if trivial, is needed for dqcMasterProtocol:
        network = Network("monolithic_computer_only")
        network.add_nodes([monolithic_computing_node]) 
        gate_tuples = [(instr.INSTR_INIT, [0, 1], "node_0"),
                       (INSTR_ARB_GEN(alpha, beta), 0, "node_0")]
        for gate_index in range(num_logical_cnots):
            gate_tuples = (gate_tuples + 
                           [(instr.INSTR_CNOT, 0, "node_0", 1, "node_0")])
            
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        if num_logical_cnots % 2 == 1: #if odd num gates
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                             + beta * np.kron(ks.s1, ks.s1))
        elif num_logical_cnots % 2 == 0: #if even num_logical_cnots
            desired_state = np.kron(alpha * ks.s0 + beta * ks.s1, ks.s0 )
        else:
            raise ValueError(f"num_logical_cnots ({num_logical_cnots}) is not an integer. It should be.")
        qubits2check = [(0, monolithic_computing_node), 
                        (1, monolithic_computing_node)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_depolar_error_cnot'] = p_depolar_error_cnot
        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
        df['num_local_cnots'] = num_logical_cnots 
        fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_experiment_tp_safe_with_analytical_noise_ionQ_aria_durations(
                                               F_werner,
                                               p_depolar_error_cnot,
                                               comm_qubit_depolar_rate,
                                               data_qubit_depolar_rate,
                                               max_num_logical_cnots,
                                               min_num_logical_cnots=1,
                                               phase = 0.,
                                               alpha=1/np.sqrt(2),
                                               sim_runtime=1e12):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    F_werner:
        Probability of Werner state distributed by Charlie to nodes being in 
        the |Phi^+> Bell state
    p_error:
        Probability of a depolarisation error occuring during each CNOT gate
    max_num_logical_cnots : int
        Max number of logical gates in toy circuit.
    min_num_logical_cnots : int, optional
        Min number of logical gates in toy circuit
    phase: float, optional
        Relative phase of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    alpha: float, optional
        Coefficient of |0> in input state of top qubit 
        alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    #TO DO: update netsquid and re-do in terms of pandas.concat
    fidelity_data = pandas.DataFrame()
    for ii in range(min_num_logical_cnots-1, max_num_logical_cnots):
        num_logical_cnots = ii + 1
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        state4distribution = werner_state(F_werner)
        network = create_dqc_network(
                                  p_depolar_error_cnot,
                                  comm_qubit_depolar_rate,
                                  data_qubit_depolar_rate,
                                  state4distribution=state4distribution,
                                  node_list=None, num_nodes=2,
                                  node_distance=4e-3, quantum_topology = None, 
                                  classical_topology = None,
                                  create_classical_2way_link=True,
                                  create_entangling_link=True,
                                  nodes_have_ebit_ready=False,
                                  node_comm_qubits_free=[0, 1],
                                  node_comm_qubit_positions=(0, 1),
                                  custom_qprocessor_func=( 
                                      create_qproc_with_analytical_noise_ionQ_aria_durations),
                                  name="noisy_network",
                                  single_qubit_gate_time=135 * 10**3,
                                  two_qubit_gate_time=600 * 10**3,
                                  measurement_time=300 * 10**3,
                                  alpha=alpha, beta=beta,
                                  num_positions=20,
                                  num_comm_qubits=2)
        alice = network.get_node("node_0")
        bob = network.get_node("node_1")
        for node in [alice, bob]:
            node.ebit_ready = False
            node.comm_qubits_free = [0, 1]
            node.comm_qubit_positions = [0, 1]
        q1, = get_data_qubit_indices(alice, 1)
        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                       (instr.INSTR_INIT, q1, bob.name),
                       (INSTR_ARB_GEN(alpha, beta), q1, alice.name)]
        for gate_index in range(num_logical_cnots):
            gate_tuples = (gate_tuples + 
                           [(instr.INSTR_CNOT, q1, alice.name, q1, bob.name, 
                             "tp_safe")])
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        if num_logical_cnots % 2 == 1: #if odd num gates
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                             + beta * np.kron(ks.s1, ks.s1))
        elif num_logical_cnots % 2 == 0: #if even num_logical_cnots
            desired_state = np.kron(alpha * ks.s0 + beta * ks.s1, ks.s0 )
        else:
            raise ValueError(f"num_logical_cnots ({num_logical_cnots}) is not an integer. It should be.")
        qubits2check = [(q1, alice), (q1, bob)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['F_werner'] = F_werner
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_depolar_error_cnot'] = p_depolar_error_cnot
        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
        df['num_logical_cnots'] = num_logical_cnots
        df['num_local_cnots'] = 3 * num_logical_cnots #as tp-safe remote cnot
                                                      #uses 3 local CNOTs (
                                                      #assuming SWAPs ideal and
                                                      #abstract - not decomposed
                                                      #into CNOTs)
        fidelity_data = fidelity_data.append(df)
    return fidelity_data


