# -*- coding: utf-8 -*-
"""
Created on Tue May 16 09:08:44 2023

@author: kenny
"""


import itertools

import numpy as np
import pandas

import netsquid as ns
from netsquid.components import instructions as instr
from netsquid.components.qprocessor import QuantumProcessor, PhysicalInstruction
from netsquid.nodes import Node, Network
from netsquid.qubits import ketstates as ks

#from the dqc_simulator package I developed:
from dqc_simulator.hardware.dqc_creation import create_dqc_network
from dqc_simulator.qlib.states import werner_state
from dqc_simulator.qlib.gates import (INSTR_ARB_GEN, INSTR_CH, 
                                      INSTR_CT, INSTR_T_DAGGER)
from dqc_simulator.software.dqc_control import dqcMasterProtocol
from dqc_simulator.util.helper import (get_data_collector,
                                       get_data_qubit_indices)
from dqc_simulator.software.compilers import sort_greedily_by_node_and_time
from dqc_simulator.hardware.noise_models import AnalyticalDepolarisationModel
from dqc_simulator.hardware.quantum_processors import (
    create_qproc_with_analytical_noise_ionQ_aria_durations)


def analytical_tp_comm_fidelity(F_werner):
    """    Calculation of the analytical fidelity for ONE teleportion and remote gate
    . Expression assumes that the distribution of the Werner state is the only 
        #error. Calculation is on 1.137.1 of paper notes. 
        
    Parameter: 
        
    F_werner: Float between 0 and 1
    The Werner state fidelity.
    """
    
    fidelity = np.sqrt((1+2*F_werner)/3)
    return fidelity


def run_cat_comm_experiment_fidelity_for_different_inputs(
                                               gate_instr,
                                               F_werner_list,
                                               phase_list,
                                               alpha_list,
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------.
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    scheme : str
    The scheme with which to 
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for alpha in alpha_list:      #alpha is assumed real here
            for phase in phase_list:
                beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                ns.sim_reset()
                ns.set_qstate_formalism(ns.QFormalism.DM)
                state4distribution = werner_state(F_werner)
                network = create_dqc_network(
                                          state4distribution=state4distribution, 
                                          node_list=None, num_nodes=2,
                                          node_distance=4e-3,
                                          quantum_topology = None, 
                                          classical_topology = None,
                                          create_classical_2way_link=True,
                                          create_entangling_link=True,
                                          nodes_have_ebit_ready=False,
                                          node_comm_qubits_free=[0, 1],
                                          node_comm_qubit_positions=[0, 1],
                                          name="linear network")
                alice = network.get_node("node_0")
                bob = network.get_node("node_1")
                q1, = get_data_qubit_indices(alice, 1)
                gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                               (instr.INSTR_INIT, q1, bob.name),
                               (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                               (gate_instr, q1, alice.name, q1, bob.name, "cat")] 
                master_protocol = dqcMasterProtocol(gate_tuples, network, 
                             compiler_func=sort_greedily_by_node_and_time)
                desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                + beta * np.kron(ks.s1, ks.s1))
                dc = get_data_collector(master_protocol, [(q1, alice), (q1, bob)],
                                        desired_state)
                master_protocol.start()
                ns.sim_run(sim_runtime)
                df = dc.dataframe
                df['F_werner'] = F_werner
                df['alpha'] = alpha
                df['phase'] = phase
                fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_tp_comm_experiment_without_teleportation_back_werner_only(
                                               gate_instr,
                                               F_werner_list,
                                               phase_list,
                                               alpha_list,
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    scheme : str
    The scheme with which to 
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for alpha in alpha_list:      #alpha is assumed real here
            for phase in phase_list:
                beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                ns.sim_reset()
                ns.set_qstate_formalism(ns.QFormalism.DM)
                state4distribution = werner_state(F_werner)
                network = create_dqc_network(
                                          state4distribution=state4distribution, 
                                          node_list=None, num_nodes=2,
                                          node_distance=4e-3, 
                                          quantum_topology = None, 
                                          classical_topology = None,
                                          create_classical_2way_link=True,
                                          create_entangling_link=True,
                                          nodes_have_ebit_ready=False,
                                          node_comm_qubits_free=[0, 1],
                                          node_comm_qubit_positions=[0, 1],
                                          name="linear network")
                alice = network.get_node("node_0")
                bob = network.get_node("node_1")
                for node in [alice, bob]:
                    node.ebit_ready = False
                    node.comm_qubits_free = [0, 1]
                    node.comm_qubit_positions = [0, 1]
                q1, = get_data_qubit_indices(alice, 1)
                gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                               (instr.INSTR_INIT, q1, bob.name),
                               (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                               (gate_instr, q1, alice.name, q1, bob.name, "tp_risky")]
                master_protocol = dqcMasterProtocol(gate_tuples, network, 
                             compiler_func=sort_greedily_by_node_and_time)
                desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                + beta * np.kron(ks.s1, ks.s1))
                dc = get_data_collector(master_protocol, [(0, bob), (q1, bob)],
                                        desired_state)
                master_protocol.start()
                ns.sim_run(sim_runtime)
                df = dc.dataframe
                df['F_werner'] = F_werner
                df['alpha'] = alpha
                df['phase'] = phase
                fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_tp_comm_experiment_with_teleportation_back_werner_only(
                                               gate_instr,
                                               F_werner_list,
                                               phase_list,
                                               alpha_list,
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    scheme : str
    The scheme with which to 
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for alpha in alpha_list:      #alpha is assumed real here
            for phase in phase_list:
                beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                ns.sim_reset()
                ns.set_qstate_formalism(ns.QFormalism.DM)
                state4distribution = werner_state(F_werner)
                network = create_dqc_network(state4distribution=state4distribution, node_list=None, num_nodes=2,
                                          node_distance=4e-3, quantum_topology = None, 
                                          classical_topology = None,
                                          create_classical_2way_link=True,
                                          create_entangling_link=True,
                                          nodes_have_ebit_ready=False,
                                          node_comm_qubits_free=[0, 1],
                                          node_comm_qubit_positions=[0, 1],
                                          name="linear network")
                alice = network.get_node("node_0")
                bob = network.get_node("node_1")
                for node in [alice, bob]:
                    node.ebit_ready = False
                    node.comm_qubits_free = [0, 1]
                    node.comm_qubit_positions = [0, 1]
                q1, = get_data_qubit_indices(alice, 1)
                gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                               (instr.INSTR_INIT, q1, bob.name),
                               (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                               (gate_instr, q1, alice.name, q1, bob.name, "tp_risky"),
                               ([], -1, bob.name, -1, alice.name, "tp_risky")]
                master_protocol = dqcMasterProtocol(gate_tuples, network, 
                             compiler_func=sort_greedily_by_node_and_time)
                desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                + beta * np.kron(ks.s1, ks.s1))
                dc = get_data_collector(master_protocol, [(0, alice), (q1, bob)],
                                        desired_state)
                master_protocol.start()
                ns.sim_run(sim_runtime)
                df = dc.dataframe
                df['F_werner'] = F_werner
                df['alpha'] = alpha
                df['phase'] = phase
                fidelity_data = fidelity_data.append(df)
    return fidelity_data



# =============================================================================
#WITH depolarisation noise on CNOT

def run_experiment_tp_no_return_gate_and_ent_errors(
                                               gate_instr,
                                               F_werner_list,
                                               p_error_list,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for p_depolar_error_cnot in p_error_list:
            ns.sim_reset()
            ns.set_qstate_formalism(ns.QFormalism.DM)
            beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
            def create_noisy_processor():
                num_positions=7
                cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_depolar_error_cnot)
                #creating processor for all Nodes
                x_gate_duration = 1
                physical_instructions = [
                    PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                    PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                        quantum_noise_model=cnot_depolar_model),
                    PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                    PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                        quantum_noise_model=None, apply_q_noise_after=False,
                                        discard=True),
                    PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                    toplology=[0, 1]),
                    PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                        topology=None)]
                qprocessor = QuantumProcessor(
                    "noisy_qprocessor", phys_instructions=physical_instructions, 
                    num_positions=num_positions, mem_noise_models=None)
                return qprocessor
            state4distribution = werner_state(F_werner)
            network = create_dqc_network(
                                      state4distribution=state4distribution,
                                      node_list=None, num_nodes=2,
                                      node_distance=4e-3,
                                      quantum_topology = None, 
                                      classical_topology = None,
                                      create_classical_2way_link=True,
                                      create_entangling_link=True,
                                      nodes_have_ebit_ready=False,
                                      node_comm_qubits_free=[0, 1],
                                      node_comm_qubit_positions=[0, 1],
                                      custom_qprocessor_func=create_noisy_processor,
                                      name="noisy_network")
            alice = network.get_node("node_0")
            bob = network.get_node("node_1")
            for node in [alice, bob]:
                node.ebit_ready = False
                node.comm_qubits_free = [0, 1]
                node.comm_qubit_positions = [0, 1]
            q1, = get_data_qubit_indices(alice, 1)
            gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                           (instr.INSTR_INIT, q1, bob.name),
                           (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                           (gate_instr, q1, alice.name, q1, bob.name, "tp_risky")]
            master_protocol = dqcMasterProtocol(gate_tuples, network, 
                         compiler_func=sort_greedily_by_node_and_time)
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                            + beta * np.kron(ks.s1, ks.s1))
            qubits2check = [(0, bob), (q1, bob)]
            dc = get_data_collector(master_protocol, qubits2check,
                                    desired_state)
            master_protocol.start()
            ns.sim_run(sim_runtime)
            df = dc.dataframe
            df['F_werner'] = F_werner
            df['alpha'] = alpha
            df['phase'] = phase
            df['p_error_cnot'] = p_depolar_error_cnot
            fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_experiment_tp_with_return_gate_and_ent_errors(
                                               gate_instr,
                                               F_werner_list,
                                               p_error_list,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for p_depolar_error_cnot in p_error_list:
            ns.sim_reset()
            ns.set_qstate_formalism(ns.QFormalism.DM)
            beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
            def create_noisy_processor():
                num_positions=7
                cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_depolar_error_cnot)
                #creating processor for all Nodes
                x_gate_duration = 1
                physical_instructions = [
                    PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                    PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                        quantum_noise_model=cnot_depolar_model),
                    PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                    PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                        quantum_noise_model=None, apply_q_noise_after=False,
                                        discard=True),
                    PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                    toplology=[0, 1]),
                    PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                        topology=None)]
                qprocessor = QuantumProcessor(
                    "noisy_qprocessor", phys_instructions=physical_instructions, 
                    num_positions=num_positions, mem_noise_models=None)
                return qprocessor
            state4distribution = werner_state(F_werner)
            network = create_dqc_network(state4distribution=state4distribution, 
                                         node_list=None, num_nodes=2,
                                      node_distance=4e-3, 
                                      quantum_topology = None, 
                                      classical_topology = None,
                                      create_classical_2way_link=True,
                                      create_entangling_link=True,
                                      nodes_have_ebit_ready=False,
                                      node_comm_qubits_free=[0, 1],
                                      node_comm_qubit_positions=[0, 1],
                                      custom_qprocessor_func=create_noisy_processor,
                                      name="noisy_network")
            alice = network.get_node("node_0")
            bob = network.get_node("node_1")
            for node in [alice, bob]:
                node.ebit_ready = False
                node.comm_qubits_free = [0, 1]
                node.comm_qubit_positions = [0, 1]
            q1, = get_data_qubit_indices(alice, 1)
            gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                           (instr.INSTR_INIT, q1, bob.name),
                           (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                           (gate_instr, q1, alice.name, q1, bob.name, "tp_risky"),
                           ([], -1, bob.name, -1, alice.name, "tp_risky")]
            master_protocol = dqcMasterProtocol(gate_tuples, network, 
                         compiler_func=sort_greedily_by_node_and_time)
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                            + beta * np.kron(ks.s1, ks.s1))
            qubits2check = [(0, alice), (q1, bob)]
            dc = get_data_collector(master_protocol, qubits2check,
                                    desired_state)
            master_protocol.start()
            ns.sim_run(sim_runtime)
            df = dc.dataframe
            df['F_werner'] = F_werner
            df['alpha'] = alpha
            df['phase'] = phase
            df['p_error_cnot'] = p_depolar_error_cnot
            fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_experiment_cat_comm_gate_and_ent_errors(
                                               gate_instr,
                                               F_werner_list,
                                               p_error_list,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for p_depolar_error_cnot in p_error_list:
            ns.sim_reset()
            ns.set_qstate_formalism(ns.QFormalism.DM)
            beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
            def create_noisy_processor():
                num_positions=7
                cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_depolar_error_cnot)
                #creating processor for all Nodes
                x_gate_duration = 1
                physical_instructions = [
                    PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                    PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                        quantum_noise_model=cnot_depolar_model),
                    PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                    PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                        quantum_noise_model=None, apply_q_noise_after=False,
                                        discard=True),
                    PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                    toplology=[0, 1]),
                    PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                        topology=None)]
                qprocessor = QuantumProcessor(
                    "noisy_qprocessor", phys_instructions=physical_instructions, 
                    num_positions=num_positions, mem_noise_models=None)
                return qprocessor
            state4distribution = werner_state(F_werner)
            network = create_dqc_network(state4distribution=state4distribution, 
                                         node_list=None, num_nodes=2,
                                      node_distance=4e-3,
                                      quantum_topology = None, 
                                      classical_topology = None,
                                      create_classical_2way_link=True,
                                      create_entangling_link=True,
                                      nodes_have_ebit_ready=False,
                                      node_comm_qubits_free=[0, 1],
                                      node_comm_qubit_positions=[0, 1],
                                      custom_qprocessor_func=create_noisy_processor,
                                      name="noisy_network")
            alice = network.get_node("node_0")
            bob = network.get_node("node_1")
            for node in [alice, bob]:
                node.ebit_ready = False
                node.comm_qubits_free = [0, 1]
                node.comm_qubit_positions = [0, 1]
            q1, = get_data_qubit_indices(alice, 1)
            gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                           (instr.INSTR_INIT, q1, bob.name),
                           (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                           (gate_instr, q1, alice.name, q1, bob.name, "cat")] 
            master_protocol = dqcMasterProtocol(gate_tuples, network, 
                         compiler_func=sort_greedily_by_node_and_time)
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                            + beta * np.kron(ks.s1, ks.s1))
            qubits2check = [(q1, alice), (q1, bob)]
            dc = get_data_collector(master_protocol, qubits2check,
                                    desired_state)
            master_protocol.start()
            ns.sim_run(sim_runtime)
            df = dc.dataframe
            df['F_werner'] = F_werner
            df['alpha'] = alpha
            df['phase'] = phase
            df['p_error_cnot'] = p_depolar_error_cnot
            fidelity_data = fidelity_data.append(df)
    return fidelity_data

def run_experiment_monolithic_gate_errors(gate_instr,
                                          p_error_list,
                                          phase = 0.0,
                                          alpha=1/np.sqrt(3),
                                          sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------

    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for p_depolar_error_cnot in p_error_list:
        ns.sim_reset()
        ns.set_qstate_formalism(ns.QFormalism.DM)
        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
        def create_noisy_processor():
            num_positions=7
            cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_depolar_error_cnot)
            #creating processor for all Nodes
            x_gate_duration = 1
            physical_instructions = [
                PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                    quantum_noise_model=cnot_depolar_model),
                PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                    quantum_noise_model=None, apply_q_noise_after=False,
                                    discard=True),
                PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                toplology=[0, 1]),
                PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                    topology=None),
                PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                    topology=None),
                PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                    topology=None)]
            qprocessor = QuantumProcessor(
                "noisy_qprocessor", phys_instructions=physical_instructions, 
                num_positions=num_positions, mem_noise_models=None)
            return qprocessor
        network = Network("monolithic_processor")
        monolithic_QC_node = Node("node_0", qmemory=create_noisy_processor())
        network.add_nodes([monolithic_QC_node])
        gate_tuples = [(instr.INSTR_INIT, [0, 1], "node_0"),
                       (INSTR_ARB_GEN(alpha, beta), 0, "node_0"),
                       (gate_instr, 0, "node_0", 1, "node_0")] 
        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                     compiler_func=sort_greedily_by_node_and_time)
        desired_state = (alpha * np.kron(ks.s0, ks.s0)
                        + beta * np.kron(ks.s1, ks.s1))
        qubits2check = [(0, monolithic_QC_node), (1, monolithic_QC_node)]
        dc = get_data_collector(master_protocol, qubits2check,
                                desired_state)
        master_protocol.start()
        ns.sim_run(sim_runtime)
        df = dc.dataframe
        df['alpha'] = alpha
        df['phase'] = phase
        df['p_error_cnot'] = p_depolar_error_cnot
        fidelity_data = fidelity_data.append(df)
    return fidelity_data


def run_experiment_tp_safe_gate_and_ent_errors(
                                               gate_instr,
                                               F_werner_list,
                                               p_error_list,
                                               phase = 0.0,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=1000):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
        
    fidelity_data = pandas.DataFrame()
    for F_werner in F_werner_list:
        for p_depolar_error_cnot in p_error_list:
            ns.sim_reset()
            ns.set_qstate_formalism(ns.QFormalism.DM)
            beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
            def create_noisy_processor():
                num_positions=7
                cnot_depolar_model = AnalyticalDepolarisationModel(p_error=p_depolar_error_cnot)
                #creating processor for all Nodes
                x_gate_duration = 1
                physical_instructions = [
                    PhysicalInstruction(instr.INSTR_INIT, duration=3, parallel=False, toplogy = [2, 3, 4, 5, 6]),
                    PhysicalInstruction(instr.INSTR_H, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_X, duration=x_gate_duration, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_Z, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_S, duration=1, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CNOT, duration=4, parallel=False, topology=None, 
                                        quantum_noise_model=cnot_depolar_model),
                    PhysicalInstruction(INSTR_ARB_GEN(alpha, beta), duration=4, parallel=False),
                    PhysicalInstruction(INSTR_CH, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(INSTR_CT, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_CS, duration=4, parallel=False, topology=None),
                    PhysicalInstruction(instr.INSTR_MEASURE, duration=7, parallel=False, topology=None,
                                        quantum_noise_model=None, apply_q_noise_after=False,
                                        discard=True),
                    PhysicalInstruction(instr.INSTR_DISCARD, duration=3, parallel=False,
                    toplology=[0, 1]),
                    PhysicalInstruction(instr.INSTR_SWAP, duration = 12, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(instr.INSTR_T, duration=1, parallel=False, 
                                        topology=None),
                    PhysicalInstruction(INSTR_T_DAGGER, duration=1, parallel=False,
                                        topology=None)]
                qprocessor = QuantumProcessor(
                    "noisy_qprocessor", phys_instructions=physical_instructions, 
                    num_positions=num_positions, mem_noise_models=None)
                return qprocessor
            state4distribution = werner_state(F_werner)
            network = create_dqc_network(state4distribution=state4distribution,
                                         node_list=None, num_nodes=2,
                                      node_distance=4e-3,
                                      quantum_topology = None, 
                                      classical_topology = None,
                                      create_classical_2way_link=True,
                                      create_entangling_link=True,
                                      nodes_have_ebit_ready=False,
                                      node_comm_qubits_free=[0, 1],
                                      node_comm_qubit_positions=[0, 1],
                                      custom_qprocessor_func=create_noisy_processor,
                                      name="noisy_network")
            alice = network.get_node("node_0")
            bob = network.get_node("node_1")
            for node in [alice, bob]:
                node.ebit_ready = False
                node.comm_qubits_free = [0, 1]
                node.comm_qubit_positions = [0, 1]
            q1, = get_data_qubit_indices(alice, 1)
            gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                           (instr.INSTR_INIT, q1, bob.name),
                           (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                           (gate_instr, q1, alice.name, q1, bob.name, "tp_safe")] 
            master_protocol = dqcMasterProtocol(gate_tuples, network, 
                         compiler_func=sort_greedily_by_node_and_time)
            desired_state = (alpha * np.kron(ks.s0, ks.s0)
                            + beta * np.kron(ks.s1, ks.s1))
            qubits2check = [(q1, alice), (q1, bob)]
            dc = get_data_collector(master_protocol, qubits2check,
                                    desired_state)
            master_protocol.start()
            ns.sim_run(sim_runtime)
            df = dc.dataframe
            df['F_werner'] = F_werner
            df['alpha'] = alpha
            df['phase'] = phase
            df['p_error_cnot'] = p_depolar_error_cnot
            fidelity_data = fidelity_data.append(df)
    return fidelity_data

#==============================================================================
#Including impact of time (ionQ Aria gate durations)


#TO DO: give option to iterate through comm and data qubit depolar rate at the 
#same time
def run_experiment_cat_comm_with_analytical_noise_ionQ_aria_durations(
                                               gate_instr=None,
                                               F_werner_list=None,
                                               alpha_list=None,
                                               phase_list=None,
                                               p_depolar_error_cnot_list=None,
                                               comm_qubit_depolar_rate_list=None,
                                               data_qubit_depolar_rate_list=None,
                                               node_distance=2e-3,
                                               ent_dist_rate=182,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=10e9,
                                               single_qubit_gate_time=135e3,
                                               two_qubit_gate_time=600e3,
                                               measurement_time=300e3,
                                               num_mem_positions=20,
                                               num_comm_qubits=2):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    ent_dist_rate : float, optional
        The rate of entanglement distribution [Hz].
    node_distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    
    #instantiating all mutable default arguments
    if gate_instr is None:
        gate_instr = instr.INSTR_CNOT
        
    if F_werner_list is None:
        F_werner_list=[1.]
        
    if alpha_list is None:
        alpha_list=[1/np.sqrt(2)]
        
    if phase_list is None:
        phase_list=[0.]
        
    if p_depolar_error_cnot_list is None:
        p_depolar_error_cnot_list=[0.]
    
    if comm_qubit_depolar_rate_list is None:
        comm_qubit_depolar_rate_list=[0.]
        
    if data_qubit_depolar_rate_list is None:
        data_qubit_depolar_rate_list=[0.]
        
        
    fidelity_data = pandas.DataFrame()
    comm_qubit_positions = [ii for ii in range(num_comm_qubits)]
    for F_werner in F_werner_list:
        for alpha in alpha_list:
            for phase in phase_list:
                for p_depolar_error_cnot in p_depolar_error_cnot_list:
                    if (comm_qubit_depolar_rate_list == 
                        data_qubit_depolar_rate_list):
                        mem_depolar_rate_iterator = [
                            (comm_qubit_depolar_rate, comm_qubit_depolar_rate)
                            for comm_qubit_depolar_rate in 
                            comm_qubit_depolar_rate_list]
                        
                    else:
                        mem_depolar_rate_iterator = (
                            itertools.product[comm_qubit_depolar_rate_list, 
                                              data_qubit_depolar_rate_list])
                    for mem_depolar_rate_tuple in mem_depolar_rate_iterator:
                        comm_qubit_depolar_rate = mem_depolar_rate_tuple[0]
                        data_qubit_depolar_rate = mem_depolar_rate_tuple[1]
                        ns.sim_reset()
                        ns.set_qstate_formalism(ns.QFormalism.DM)
                        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                        state4distribution = werner_state(F_werner)
                        network = create_dqc_network(
                            p_depolar_error_cnot,
                            comm_qubit_depolar_rate,
                            data_qubit_depolar_rate,
                            state4distribution=state4distribution,
                            node_list=None, num_nodes=2,
                            node_distance=node_distance,
                            ent_dist_rate=ent_dist_rate,
                            quantum_topology = None, 
                            classical_topology = None,
                            create_classical_2way_link=True,
                            create_entangling_link=True,
                            nodes_have_ebit_ready=False,
                            node_comm_qubits_free=comm_qubit_positions,
                            node_comm_qubit_positions=comm_qubit_positions,
                            custom_qprocessor_func=create_qproc_with_analytical_noise_ionQ_aria_durations,
                            name="noisy_network",
                            single_qubit_gate_time=single_qubit_gate_time,
                            two_qubit_gate_time=two_qubit_gate_time,
                            measurement_time=measurement_time,
                            alpha=alpha, beta=beta,
                            num_positions=num_mem_positions, 
                            num_comm_qubits=num_comm_qubits)
                        alice = network.get_node("node_0")
                        bob = network.get_node("node_1")
                        for node in [alice, bob]:
                            node.comm_qubits_free = [0, 1]
                                #TO DO: resolve bug here.
                                #Changing [0, 1] to comm_qubit_positions 
                                #(which has the same value) causes a 
                                #scheduling error. I have tried different 
                                #names for comm_qubit_positions to no 
                                #avail. See MWE4comm_qubits_free_attribute_
                                #not_reinitialising.py for more on the 
                                #buggy behaviour of comm_qubits_free
                        q1, = get_data_qubit_indices(alice, 1)
                        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                                       (instr.INSTR_INIT, q1, bob.name),
                                       (INSTR_ARB_GEN(alpha, beta), q1,
                                        alice.name),
                                       (gate_instr, q1, alice.name, q1,
                                        bob.name, "cat")] 
                        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                                     compiler_func=sort_greedily_by_node_and_time)
                        desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                        + beta * np.kron(ks.s1, ks.s1))
                        qubits2check = [(q1, alice), (q1, bob)]
                        dc = get_data_collector(master_protocol, qubits2check,
                                                desired_state)
                        master_protocol.start()
                        ns.sim_run(sim_runtime)
                        df = dc.dataframe
                        df['F_werner'] = F_werner
                        df['alpha'] = alpha
                        df['phase'] = phase
                        df['p_error_cnot'] = p_depolar_error_cnot
                        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
                        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
                        fidelity_data = fidelity_data.append(df)
    return fidelity_data 

def run_experiment_single_tele_tp_with_analytical_noise_ionQ_aria_durations(
                                               gate_instr=None,
                                               F_werner_list=None,
                                               alpha_list=None,
                                               phase_list=None,
                                               p_depolar_error_cnot_list=None,
                                               comm_qubit_depolar_rate_list=None,
                                               data_qubit_depolar_rate_list=None,
                                               node_distance=2e-3,
                                               ent_dist_rate=10,
                                               alpha=1/np.sqrt(3),
                                               sim_runtime=10e9,
                                               single_qubit_gate_time=135e3,
                                               two_qubit_gate_time=600e3,
                                               measurement_time=300e3,
                                               num_mem_positions=20,
                                               num_comm_qubits=2):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    node_distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    ent_dist_rate : float, optional
        The rate of entanglement distribution [Hz].
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    
    #instantiating all mutable default arguments
    if gate_instr is None:
        gate_instr=instr.INSTR_CNOT
    
    if F_werner_list is None:
        F_werner_list=[1.]
        
    if alpha_list is None:
        alpha_list=[1/np.sqrt(2)]
    
    if phase_list is None:
        phase_list=[0.]
    
    if p_depolar_error_cnot_list is None:
        p_depolar_error_cnot_list=[0.]
        
    if comm_qubit_depolar_rate_list is None:
        comm_qubit_depolar_rate_list=[0.]
        
    if data_qubit_depolar_rate_list is None:
        data_qubit_depolar_rate_list=[0.]
    
    fidelity_data = pandas.DataFrame()
    comm_qubit_positions = [ii for ii in range(num_comm_qubits)]
    for F_werner in F_werner_list:
        for alpha in alpha_list:
            for phase in phase_list:
                for p_depolar_error_cnot in p_depolar_error_cnot_list:
                    if (comm_qubit_depolar_rate_list == 
                        data_qubit_depolar_rate_list):
                        mem_depolar_rate_iterator = [
                            (comm_qubit_depolar_rate, comm_qubit_depolar_rate)
                            for comm_qubit_depolar_rate in 
                            comm_qubit_depolar_rate_list]
                        
                    else:
                        mem_depolar_rate_iterator = (
                            itertools.product[comm_qubit_depolar_rate_list, 
                                              data_qubit_depolar_rate_list])
                    for mem_depolar_rate_tuple in mem_depolar_rate_iterator:
                        comm_qubit_depolar_rate = mem_depolar_rate_tuple[0]
                        data_qubit_depolar_rate = mem_depolar_rate_tuple[1]
                        ns.sim_reset()
                        ns.set_qstate_formalism(ns.QFormalism.DM)
                        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                        state4distribution = werner_state(F_werner)
                        network = create_dqc_network(
                            p_depolar_error_cnot,
                            comm_qubit_depolar_rate,
                            data_qubit_depolar_rate,
                            state4distribution=state4distribution,
                            node_list=None, num_nodes=2,
                            node_distance=node_distance,
                            ent_dist_rate=ent_dist_rate,
                            quantum_topology = None, 
                            classical_topology = None,
                            create_classical_2way_link=True,
                            create_entangling_link=True,
                            nodes_have_ebit_ready=False,
                            node_comm_qubits_free=comm_qubit_positions,
                            node_comm_qubit_positions=comm_qubit_positions,
                            custom_qprocessor_func=create_qproc_with_analytical_noise_ionQ_aria_durations,
                            name="noisy_network",
                            single_qubit_gate_time=single_qubit_gate_time,
                            two_qubit_gate_time=two_qubit_gate_time,
                            measurement_time=measurement_time,
                            alpha=alpha, beta=beta,
                            num_positions=num_mem_positions, 
                            num_comm_qubits=num_comm_qubits)
                        alice = network.get_node("node_0")
                        bob = network.get_node("node_1")
                        for node in [alice, bob]:
                            node.comm_qubits_free = [0, 1]
                                #TO DO: resolve bug here.
                                #Changing [0, 1] to comm_qubit_positions 
                                #(which has the same value) causes a 
                                #scheduling error. I have tried different 
                                #names for comm_qubit_positions to no 
                                #avail. See MWE4comm_qubits_free_attribute_
                                #not_reinitialising.py for more on the 
                                #buggy behaviour of comm_qubits_free
                        q1, = get_data_qubit_indices(alice, 1)
                        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                           (instr.INSTR_INIT, q1, bob.name),
                           (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                           (gate_instr, q1, alice.name, q1, bob.name, "tp_risky")]
                        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                                     compiler_func=sort_greedily_by_node_and_time)
                        desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                        + beta * np.kron(ks.s1, ks.s1))
                        qubits2check = [(0, bob), (q1, bob)]
                        dc = get_data_collector(master_protocol, qubits2check,
                                                desired_state)
                        master_protocol.start()
                        ns.sim_run(sim_runtime)
                        df = dc.dataframe
                        df['F_werner'] = F_werner
                        df['alpha'] = alpha
                        df['phase'] = phase
                        df['p_error_cnot'] = p_depolar_error_cnot
                        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
                        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
                        fidelity_data = fidelity_data.append(df)
    return fidelity_data 

def run_experiment_two_tele_tp_with_analytical_noise_ionQ_aria_durations(
                                               gate_instr=None,
                                               F_werner_list=None,
                                               alpha_list=None,
                                               phase_list=None,
                                               p_depolar_error_cnot_list=None,
                                               comm_qubit_depolar_rate_list=None,
                                               data_qubit_depolar_rate_list=None,
                                               node_distance=2e-3,
                                               ent_dist_rate=182,
                                               sim_runtime=10e9,
                                               single_qubit_gate_time=135e3,
                                               two_qubit_gate_time=600e3,
                                               measurement_time=300e3,
                                               num_mem_positions=20,
                                               num_comm_qubits=2):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    ent_dist_rate : float, optional
        The rate of entanglement distribution [Hz].
    node_distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    
    #instantiating all mutable default arguments
    if gate_instr is None:
        gate_instr=instr.INSTR_CNOT
    
    if F_werner_list is None:
        F_werner_list=[1.]
        
    if alpha_list is None:
        alpha_list=[1/np.sqrt(2)]
    
    if phase_list is None:
        phase_list=[0.]
    
    if p_depolar_error_cnot_list is None:
        p_depolar_error_cnot_list=[0.]
        
    if comm_qubit_depolar_rate_list is None:
        comm_qubit_depolar_rate_list=[0.]
        
    if data_qubit_depolar_rate_list is None:
        data_qubit_depolar_rate_list=[0.]
    
    fidelity_data = pandas.DataFrame()
    comm_qubit_positions = [ii for ii in range(num_comm_qubits)]

    for F_werner in F_werner_list:
        for alpha in alpha_list:
            for phase in phase_list:
                for p_depolar_error_cnot in p_depolar_error_cnot_list:
                    if (comm_qubit_depolar_rate_list == 
                        data_qubit_depolar_rate_list):
                        mem_depolar_rate_iterator = [
                            (comm_qubit_depolar_rate, comm_qubit_depolar_rate)
                            for comm_qubit_depolar_rate in 
                            comm_qubit_depolar_rate_list]
                        
                    else:
                        mem_depolar_rate_iterator = (
                            itertools.product[comm_qubit_depolar_rate_list, 
                                              data_qubit_depolar_rate_list])
                    for mem_depolar_rate_tuple in mem_depolar_rate_iterator:
                        comm_qubit_depolar_rate = mem_depolar_rate_tuple[0]
                        data_qubit_depolar_rate = mem_depolar_rate_tuple[1]
                        ns.sim_reset()
                        ns.set_qstate_formalism(ns.QFormalism.DM)
                        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                        state4distribution = werner_state(F_werner)
                        network = create_dqc_network(
                            p_depolar_error_cnot,
                            comm_qubit_depolar_rate,
                            data_qubit_depolar_rate,
                            state4distribution=state4distribution,
                            node_list=None, num_nodes=2,
                            node_distance=node_distance,
                            ent_dist_rate=ent_dist_rate,
                            quantum_topology = None, 
                            classical_topology = None,
                            create_classical_2way_link=True,
                            create_entangling_link=True,
                            nodes_have_ebit_ready=False,
                            node_comm_qubits_free=comm_qubit_positions,
                            node_comm_qubit_positions=comm_qubit_positions,
                            custom_qprocessor_func=create_qproc_with_analytical_noise_ionQ_aria_durations,
                            name="noisy_network",
                            single_qubit_gate_time=single_qubit_gate_time,
                            two_qubit_gate_time=two_qubit_gate_time,
                            measurement_time=measurement_time,
                            alpha=alpha, beta=beta,
                            num_positions=num_mem_positions, 
                            num_comm_qubits=num_comm_qubits)
                        alice = network.get_node("node_0")
                        bob = network.get_node("node_1")
                        for node in [alice, bob]:
                            node.comm_qubits_free = [0, 1]
                                #TO DO: resolve bug here.
                                #Changing [0, 1] to comm_qubit_positions 
                                #(which has the same value) causes a 
                                #scheduling error. I have tried different 
                                #names for comm_qubit_positions to no 
                                #avail. See MWE4comm_qubits_free_attribute_
                                #not_reinitialising.py for more on the 
                                #buggy behaviour of comm_qubits_free
                        q1, = get_data_qubit_indices(alice, 1)
                        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                                       (instr.INSTR_INIT, q1, bob.name),
                                       (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                                       (gate_instr, q1, alice.name, q1, bob.name, "tp_risky"),
                                       ([], -1, bob.name, -1, alice.name, "tp_risky")]
                        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                                     compiler_func=sort_greedily_by_node_and_time)
                        desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                        + beta * np.kron(ks.s1, ks.s1))
                        qubits2check = [(0, alice), (q1, bob)]
                        dc = get_data_collector(master_protocol, qubits2check,
                                                desired_state)
                        master_protocol.start()
                        ns.sim_run(sim_runtime)
                        df = dc.dataframe
                        df['F_werner'] = F_werner
                        df['alpha'] = alpha
                        df['phase'] = phase
                        df['p_error_cnot'] = p_depolar_error_cnot
                        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
                        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
                        fidelity_data = fidelity_data.append(df)
    return fidelity_data 

def run_experiment_tp_safe_with_analytical_noise_ionQ_aria_durations(
                                               gate_instr=None,
                                               F_werner_list=None,
                                               alpha_list=None,
                                               phase_list=None,
                                               p_depolar_error_cnot_list=None,
                                               comm_qubit_depolar_rate_list=None,
                                               data_qubit_depolar_rate_list=None,
                                               node_distance=2e-3,
                                               ent_dist_rate=182,
                                               sim_runtime=10e9,
                                               single_qubit_gate_time=135e3,
                                               two_qubit_gate_time=600e3,
                                               measurement_time=300e3,
                                               num_mem_positions=20,
                                               num_comm_qubits=2):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    ent_dist_rate : float, optional
        The rate of entanglement distribution [Hz].
    node_distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    
    #instantiating all mutable default arguments
    if gate_instr is None:
        gate_instr=instr.INSTR_CNOT
    
    if F_werner_list is None:
        F_werner_list=[1.]
        
    if alpha_list is None:
        alpha_list=[1/np.sqrt(2)]
    
    if phase_list is None:
        phase_list=[0.]
    
    if p_depolar_error_cnot_list is None:
        p_depolar_error_cnot_list=[0.]
        
    if comm_qubit_depolar_rate_list is None:
        comm_qubit_depolar_rate_list=[0.]
        
    if data_qubit_depolar_rate_list is None:
        data_qubit_depolar_rate_list=[0.]
        
    fidelity_data = pandas.DataFrame()
    comm_qubit_positions = [ii for ii in range(num_comm_qubits)]

    for F_werner in F_werner_list:
        for alpha in alpha_list:
            for phase in phase_list:
                for p_depolar_error_cnot in p_depolar_error_cnot_list:
                    if (comm_qubit_depolar_rate_list == 
                        data_qubit_depolar_rate_list):
                        mem_depolar_rate_iterator = [
                            (comm_qubit_depolar_rate, comm_qubit_depolar_rate)
                            for comm_qubit_depolar_rate in 
                            comm_qubit_depolar_rate_list]
                        
                    else:
                        mem_depolar_rate_iterator = (
                            itertools.product[comm_qubit_depolar_rate_list, 
                                              data_qubit_depolar_rate_list])
                    for mem_depolar_rate_tuple in mem_depolar_rate_iterator:
                        comm_qubit_depolar_rate = mem_depolar_rate_tuple[0]
                        data_qubit_depolar_rate = mem_depolar_rate_tuple[1]
                        ns.sim_reset()
                        ns.set_qstate_formalism(ns.QFormalism.DM)
                        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                        state4distribution = werner_state(F_werner)
                        network = create_dqc_network(
                            p_depolar_error_cnot,
                            comm_qubit_depolar_rate,
                            data_qubit_depolar_rate,
                            state4distribution=state4distribution,
                            node_list=None, num_nodes=2,
                            node_distance=node_distance,
                            ent_dist_rate=ent_dist_rate,
                            quantum_topology = None, 
                            classical_topology = None,
                            create_classical_2way_link=True,
                            create_entangling_link=True,
                            nodes_have_ebit_ready=False,
                            node_comm_qubits_free=comm_qubit_positions,
                            node_comm_qubit_positions=comm_qubit_positions,
                            custom_qprocessor_func=create_qproc_with_analytical_noise_ionQ_aria_durations,
                            name="noisy_network",
                            single_qubit_gate_time=single_qubit_gate_time,
                            two_qubit_gate_time=two_qubit_gate_time,
                            measurement_time=measurement_time,
                            alpha=alpha, beta=beta,
                            num_positions=num_mem_positions, 
                            num_comm_qubits=num_comm_qubits)
                        alice = network.get_node("node_0")
                        bob = network.get_node("node_1")
                        for node in [alice, bob]:
                            node.ebit_ready = False
                            node.comm_qubits_free = [0, 1]
                                #TO DO: resolve bug here.
                                #Changing [0, 1] to comm_qubit_positions 
                                #(which has the same value) causes a 
                                #scheduling error. I have tried different 
                                #names for comm_qubit_positions to no 
                                #avail. See MWE4comm_qubits_free_attribute_
                                #not_reinitialising.py for more on the 
                                #buggy behaviour of comm_qubits_free
                            node.comm_qubit_positions = comm_qubit_positions
                        q1, = get_data_qubit_indices(alice, 1)
                        gate_tuples = [(instr.INSTR_INIT, q1, alice.name),
                                       (instr.INSTR_INIT, q1, bob.name),
                                       (INSTR_ARB_GEN(alpha, beta), q1, alice.name),
                                       (gate_instr, q1, alice.name, q1, bob.name, "tp_safe")] 
                        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                                     compiler_func=sort_greedily_by_node_and_time)
                        desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                        + beta * np.kron(ks.s1, ks.s1))
                        qubits2check = [(q1, alice), (q1, bob)]
                        dc = get_data_collector(master_protocol, qubits2check,
                                                desired_state)
                        master_protocol.start()
                        ns.sim_run(sim_runtime)
                        df = dc.dataframe
                        df['F_werner'] = F_werner
                        df['alpha'] = alpha
                        df['phase'] = phase
                        df['p_error_cnot'] = p_depolar_error_cnot
                        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
                        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
                        fidelity_data = fidelity_data.append(df)
    return fidelity_data 

def run_experiment_monolithic_with_analytical_noise_ionQ_aria_durations(
                                               gate_instr=instr.INSTR_CNOT,
                                               F_werner_list=[1.],
                                               alpha_list=[1/np.sqrt(2)],
                                               phase_list=[0.],
                                               p_depolar_error_cnot_list=[0.],
                                               comm_qubit_depolar_rate_list=[0.],
                                               data_qubit_depolar_rate_list=[0.],
                                               sim_runtime=10e9,
                                               single_qubit_gate_time=135e3,
                                               two_qubit_gate_time=600e3,
                                               measurement_time=300e3,
                                               num_mem_positions=20,
                                               num_comm_qubits=2):
    """Setup and run the simulation experiment. By default there is no 
        depolarisation or dephasing noise on the memories (only imposed by 
                                                           gates)

    Parameters
    ----------
    gate_instr: netsquid.components.instructions.Instruction 
        Gate instruction for the remote gate. Eg, instr.INSTR_CNOT
    F_werner_list: list of floats
        List of F_werner values for Werner state distributed by Charlie to nodes
    phase_list: list of floats
        List of relative phases of beta relative to alpha. Phase is such that
        |alice_program_qubit> = alpha|0> + exp(i phase) sqrt(1-|alpha|^2)|1>
    ent_dist_rate : float, optional
        The rate of entanglement distribution [Hz].
    node_distance : float, optional
        Distance between nodes [km]. Default of 4e-3 is constructed so that it 
        gives default frequency of 100Hz in the StateSampler
    sim_runtime : float, optional
        The length of time the sim will run for in ns

    Returns
    -------
    :class:`pandas.DataFrame`
        Dataframe with recorded fidelity data.

    """
    
    #instantiating all mutable default arguments
    if gate_instr is None:
        gate_instr=instr.INSTR_CNOT
    
    if F_werner_list is None:
        F_werner_list=[1.]
        
    if alpha_list is None:
        alpha_list=[1/np.sqrt(2)]
    
    if phase_list is None:
        phase_list=[0.]
    
    if p_depolar_error_cnot_list is None:
        p_depolar_error_cnot_list=[0.]
        
    if comm_qubit_depolar_rate_list is None:
        comm_qubit_depolar_rate_list=[0.]
        
    if data_qubit_depolar_rate_list is None:
        data_qubit_depolar_rate_list=[0.]
    
    fidelity_data = pandas.DataFrame()
    comm_qubit_positions = [ii for ii in range(num_comm_qubits)]

    for F_werner in F_werner_list:
        for alpha in alpha_list:
            for phase in phase_list:
                for p_depolar_error_cnot in p_depolar_error_cnot_list:
                    if (comm_qubit_depolar_rate_list == 
                        data_qubit_depolar_rate_list):
                        mem_depolar_rate_iterator = [
                            (comm_qubit_depolar_rate, comm_qubit_depolar_rate)
                            for comm_qubit_depolar_rate in 
                            comm_qubit_depolar_rate_list]
                        
                    else:
                        mem_depolar_rate_iterator = (
                            itertools.product[comm_qubit_depolar_rate_list, 
                                              data_qubit_depolar_rate_list])
                    for mem_depolar_rate_tuple in mem_depolar_rate_iterator:
                        comm_qubit_depolar_rate = mem_depolar_rate_tuple[0]
                        data_qubit_depolar_rate = mem_depolar_rate_tuple[1]
                        ns.sim_reset()
                        ns.set_qstate_formalism(ns.QFormalism.DM)
                        beta = np.exp(1j * phase) * np.sqrt(1 - abs(alpha)**2) 
                        network = Network("monolithic_processor")
                        monolithic_QC_node = (
                            Node("node_0",
                                 qmemory=
                                     create_qproc_with_analytical_noise_ionQ_aria_durations(
                                        p_depolar_error_cnot,
                                        comm_qubit_depolar_rate,
                                        data_qubit_depolar_rate,
                                        single_qubit_gate_time=single_qubit_gate_time,
                                        two_qubit_gate_time=two_qubit_gate_time,
                                        measurement_time=measurement_time,
                                        alpha=alpha, beta=beta,
                                        num_positions=num_mem_positions,
                                        num_comm_qubits=0)))
                        
                        monolithic_QC_node.comm_qubit_positions = [0, 1]
                        monolithic_QC_node.ebit_ready = False
                        monolithic_QC_node.comm_qubits_free = [0, 1]
                            #TO DO: resolve bug here.
                            #Changing [0, 1] to comm_qubit_positions 
                            #(which has the same value) causes a 
                            #scheduling error. I have tried different 
                            #names for comm_qubit_positions to no 
                            #avail. See MWE4comm_qubits_free_attribute_
                            #not_reinitialising.py for more on the 
                            #buggy behaviour of comm_qubits_free
                        network.add_nodes([monolithic_QC_node])
                        gate_tuples = [(instr.INSTR_INIT, [0, 1], "node_0"),
                                       (INSTR_ARB_GEN(alpha, beta), 0, "node_0"),
                                       (gate_instr, 0, "node_0", 1, "node_0")] 
                        master_protocol = dqcMasterProtocol(gate_tuples, network, 
                                     compiler_func=sort_greedily_by_node_and_time)
                        desired_state = (alpha * np.kron(ks.s0, ks.s0)
                                        + beta * np.kron(ks.s1, ks.s1))
                        qubits2check = [(0, monolithic_QC_node),
                                        (1, monolithic_QC_node)]
                        dc = get_data_collector(master_protocol, qubits2check,
                                                desired_state)
                        master_protocol.start()
                        ns.sim_run(sim_runtime)
                        df = dc.dataframe
                        df['F_werner'] = F_werner
                        df['alpha'] = alpha
                        df['phase'] = phase
                        df['p_error_cnot'] = p_depolar_error_cnot
                        df['comm_qubit_depolar_rate'] = comm_qubit_depolar_rate
                        df['data_qubit_depolar_rate'] = data_qubit_depolar_rate
                        fidelity_data = fidelity_data.append(df)
    return fidelity_data 

#TO DO: potentially exhange comm_qubit_positions for num_comm_qubits and a 
#corresponding list in network.py and then change everywhere else. Right now
#you redundantly have both comm_qubit positions and num_comm_qubits specified
#once in the processor and once during network creation.

